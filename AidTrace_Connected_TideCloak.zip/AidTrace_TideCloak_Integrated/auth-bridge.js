// TideCloak / standard Keycloak-compatible OIDC adapter for the aidtrace-demo realm.
// This is REAL browser login, but it is NOT the separately licensed Tide cryptographic SDK.
// Pinned adapter is loaded from jsDelivr; internet access is required for this library.
const settings = Object.freeze({
  url: 'http://localhost:8080',
  realm: 'aidtrace-demo',
  clientId: 'aidtrace-web',
});
const signal = () => window.dispatchEvent(new Event('tide-auth-changed'));
const auth = {
  authenticated: false,
  username: '',
  error: 'Loading authentication…',
  hasRole: () => false,
  login() { /* enabled after the adapter initializes */ },
  logout() { /* enabled after the adapter initializes */ },
  encryptNote: async () => { throw new Error('Tide encryption requires a licensed realm and is not configured.'); },
  decryptNote: async () => { throw new Error('Tide encryption requires a licensed realm and is not configured.'); },
};
window.AidTraceAuth = auth;
signal();

try {
  const { default: Keycloak } = await import('https://cdn.jsdelivr.net/npm/keycloak-js@26.2.2/+esm');
  const keycloak = new Keycloak(settings);
  const redirectUri = `${window.location.origin}/secure.html`;
  auth.login = () => keycloak.login({ redirectUri });
  auth.logout = () => keycloak.logout({ redirectUri });
  keycloak.onAuthLogout = () => {
    auth.authenticated = false;
    auth.username = '';
    auth.hasRole = () => false;
    signal();
  };
  const loggedIn = await keycloak.init({
    onLoad: 'check-sso',
    flow: 'standard',
    pkceMethod: 'S256',
    checkLoginIframe: false,
    silentCheckSsoFallback: false,
  });
  const applyLogin = () => {
    auth.authenticated = !!keycloak.authenticated;
    auth.username = auth.authenticated
      ? String(keycloak.tokenParsed?.preferred_username || keycloak.tokenParsed?.name || keycloak.subject || 'reviewer')
      : '';
    auth.hasRole = (role) => !!keycloak.authenticated &&
      ((keycloak.realmAccess?.roles || []).includes(role) ||
       (keycloak.resourceAccess?.[settings.clientId]?.roles || []).includes(role));
    auth.error = '';
    signal();
  };
  applyLogin();
  if (loggedIn) {
    // Keep adapter's in-memory tokens fresh; no tokens are stored in localStorage.
    keycloak.onTokenExpired = async () => {
      try { await keycloak.updateToken(30); applyLogin(); }
      catch { auth.authenticated = false; auth.error = 'Session expired. Please sign in again.'; signal(); }
    };
  }
} catch (error) {
  console.error('TideCloak standard authentication could not be initialized:', error);
  auth.error = 'Login unavailable: check Docker port 8080, realm/client settings, and internet/CDN access.';
  auth.authenticated = false;
  signal();
}
