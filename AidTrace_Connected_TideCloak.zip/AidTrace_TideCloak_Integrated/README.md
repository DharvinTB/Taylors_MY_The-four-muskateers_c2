# AidTrace — Connected Donation Data + TideCloak standard login

This is your **uploaded `AidTrace_Connected_Donation_Data.zip` design**, with its same campaign, donation history, local donation and delivery demo features.

## FASTEST START (Mac, no `npm install`, no `package.json`)

1. Extract `AidTrace_Connected_TideCloak.zip`.
2. Open the resulting `AidTrace_TideCloak_Integrated` folder in VS Code.
3. In VS Code choose **Terminal → New Terminal**. If the terminal is in the wrong folder, right-click `server.mjs` in VS Code, choose **Copy Path**, then type `cd "$(dirname "$(pbpaste)")"`.
4. Run `node server.mjs` (Node.js 24 is already installed on your Mac).
5. Open `http://localhost:5173/` to see the normal AidTrace app.
6. Open `http://localhost:5173/secure.html` to see TideCloak login mode. Click **Sign in**.

## TIDECLOAK CLIENT SETUP (existing realm only)

Keep your **original** TideCloak Docker container running at `http://localhost:8080`. Use `docker ps` and `docker start aidtrace-tidecloak` if needed. Do **not** use the second instance on port 8081 for this demo.

Open `http://localhost:8080/admin/master/console/` and log in as the admin. Select existing realm `aidtrace-demo` in the upper left. In **Clients**, create or open `aidtrace-web` with:

- Client type: OpenID Connect
- Client authentication: OFF (public browser client)
- Standard flow: ON
- Direct access grants: OFF
- Implicit flow: OFF
- Root URL: `http://localhost:5173`
- Home URL: `http://localhost:5173/secure.html`
- Valid redirect URIs: `http://localhost:5173/secure.html`
- Valid post logout redirect URIs: `http://localhost:5173/secure.html`
- Web origins: `http://localhost:5173`

Save. Under **Users**, create test account `reviewer1`. Go to **Credentials**, set password, and toggle **Temporary OFF**. Use a demo-only unique password.

Sign in on `http://localhost:5173/secure.html`, click **Admin Portal**. It should show authenticated identity. If signing in fails, check the client settings and the browser DevTools Console.

## REVIEWER ROLE TESTS (optional)

In realm `aidtrace-demo`, create realm roles:
- `aidtrace-compliance`
- `aidtrace-risk`
- `aidtrace-dispatch`
- `aidtrace-receiver`

Assign `aidtrace-compliance` to `reviewer1`. Create `reviewer2` with `aidtrace-risk` and assign it in **Role mapping**. For logistics demo, you can similarly assign dispatch/receiver to two different users. The app checks matching role **claims in the browser** before enabling the respective review buttons.

If roles are missing, check **Client scopes → roles** and the client's effective/default client scopes so the user's roles appear in the access token. Log out and log back in to refresh role claims.

## DEMO LIMITATIONS — IMPORTANT

- **Real**: authentication is handled by the TideCloak-hosted, Keycloak-compatible `aidtrace-demo` realm via the standard `keycloak-js` JavaScript adapter, using Authorization Code + PKCE. When successfully configured, users log in through TideCloak.
- **Not real**: Tide's cryptographic key custody, licensed realm setup, Tide-specific encryption and QEA quorum approvals. The earlier Tide vendor-wallet license error is **not** fixed by this package.
- **Not secure backend authorization**: the buttons check reviewer roles client-side only. Approval events, donations, campaign totals, delivery statuses and audit entries remain editable browser-local demo data. Real enforcement requires a server that validates access tokens, roles and partner signatures.
- **Not real donations**: no payments or deliveries occur. The campaign records are synthetic; named organizations are not AidTrace partners. Do not use live donation or personal data.
- The `keycloak-js` adapter is loaded from the pinned URL `https://cdn.jsdelivr.net/npm/keycloak-js@26.2.2/+esm`, requiring an internet connection. If offline, the donation dashboard still works, but login cannot initialize.
- Don't publish a local TideCloak admin password, tokens, or any user credentials in GitHub.

For your hackathon, explain clearly which elements are TideCloak **standard identity integration** and which are simulated. If the rubric requires the Tide cryptographic extension, this fallback does not fully satisfy that requirement.

**Node command:** `node server.mjs` — no `npm install`, `npm run dev`, or `package.json` needed.
